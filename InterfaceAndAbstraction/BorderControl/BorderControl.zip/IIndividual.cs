﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IIndividual
    {
        string Name { get; set; }
        string ID { get; set; }
    }
}
