﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Interface
{
    public interface IBrowable
    {
        string Brows(string url);
    }
}
