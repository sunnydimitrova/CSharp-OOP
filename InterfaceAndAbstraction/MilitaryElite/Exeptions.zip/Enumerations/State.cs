﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Enumerations
{
    public enum State
    {
        inProgress,
        Finished,
    }
}
